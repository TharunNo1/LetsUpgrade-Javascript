let  sec = 0, min = 0, hrs = 0, iteration = 1;
let status = "stopped", interval = null;

function stopwatch() {
        sec++;
        if (sec / 60 == 1) {
            sec = 0;
            min++;
            if (min / 60 == 1) {
                min = 0;
                hrs++;
            }
        }
    document.getElementById("displayTime").innerHTML = (hrs < 10 ? "0" + hrs : hrs) + ":" + (min < 10 ? "0" + min : min) + ":" + (sec < 10 ? "0" + sec : sec) ;

}

function start() {
    if (status === "stopped") {
        interval = window.setInterval(stopwatch,1000);
        status = "started"
    }
}
                                    
function stop() {
    if (status !== "stopped") {
        clearInterval(interval);
        status = "stopped";
    }
}

function reset() {
    clearInterval(interval);
    hrs = min = sec = 0;
    status = "stopped";
    document.getElementById("displayTime").innerHTML = "00:00:00";
    document.getElementById("tlaps").innerHTML = " ";
    iteration = 1;
}

function getTime() {
    return (iteration++ + ")   " + (hrs < 10 ? "0" + hrs : hrs) + ":" + (min < 10 ? "0" + min : min) + ":" + (sec < 10 ? "0" + sec : sec));
}

function lap() {
    if (status != "stopped") {
        var list = document.createElement('tr');
        var text = document.createTextNode(getTime());
        list.appendChild(text);
        document.getElementById("tlaps").append(list);
    }

}

function setUserTime(){
    var obj = new Date();
    sec = obj.getSeconds();
    min = obj.getMinutes();
    hrs = obj.getHours() ;
    document.getElementById("displayTime").innerHTML = (hrs < 10 ? "0" + hrs : hrs) + ":" + (min < 10 ? "0" + min : min) + ":" + (sec < 10 ? "0" + sec : sec) ;
}

function getUserTime(){
    hrs = prompt("Enter the hour:",0);
    min = prompt("Enter the minute:",0);
    sec = prompt("Enter the seconds:",0);
}